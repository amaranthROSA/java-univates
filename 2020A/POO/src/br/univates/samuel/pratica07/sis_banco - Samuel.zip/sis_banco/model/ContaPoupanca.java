package br.univates.samuel.pratica07.sis_banco.model;

import br.univates.samuel.pratica07.sis_banco.data.Data;

/**
 * @author amaranth.rosa
 */

public class ContaPoupanca {

	private boolean contaBloqueada;
	private Long codigoConta;
	private Double saldo;
	private Double limite;
	private Data utlimaMovimentacao;

	public void isContaBloqueada(boolean bloqueada) {
		// TODO Auto-generated method stub

	}

	public void setCodigoConta(Long codigo) {
		// TODO Auto-generated method stub

	}

	public Long getCodigoConta() {
		// TODO Auto-generated method stub
		return null;
	}

	public void sacar() {
		// TODO Auto-generated method stub

	}

	public void depositar() {
		// TODO Auto-generated method stub

	}

	public void setLimite() {
		// TODO Auto-generated method stub

	}

	public Double getLimite() {
		// TODO Auto-generated method stub
		return null;
	}

	public void consultaSaldoDevedor() {
		// TODO Auto-generated method stub

	}

	public void transfereValor(ContaCorrente conta, double valor) {
		// TODO Auto-generated method stub

	}

	public void pagarBeleto(ContaCorrente conta, double valor) {
		// TODO Auto-generated method stub

	}

}
